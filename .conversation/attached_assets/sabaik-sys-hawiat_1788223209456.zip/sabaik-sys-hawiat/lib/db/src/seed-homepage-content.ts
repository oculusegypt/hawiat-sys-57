import { db } from "./index";
import { siteSettingsTable } from "./schema/settings";
import { eq } from "drizzle-orm";

export const homepageContent = {
  about: {
    eyebrow: "من نحن",
    title: "شريكك الرائد في",
    highlight: "تأجير الحاويات وإدارة المخلفات",
    description: "{{company_name}} خيارك الأمثل في عالم تأجير الحاويات ونقل الأنقاض ومخلفات البناء والهدم والنفايات في مدينة الرياض. نقدم خدماتنا بأسطول حديث ومعايير سلامة بيئية صارمة وسرعة استجابة فائقة.",
    visionTitle: "رؤيتنا",
    visionDescription: "أن نكون المنصة والمؤسسة الأولى المعتمدة في المملكة في تقديم الحلول اللوجستية وتأجير الحاويات وإدارة المخلفات.",
    missionTitle: "رسالتنا",
    missionDescription: "توفير حلول فورية وموثوقة لإزالة ونقل الأنقاض والمخلفات بأعلى كفاءة وأفضل الأسعار لخدمة المقاولين والمطورين والأفراد.",
    points: [
      "أسطول شاحنات وحاويات بمقاسات متنوعة من 6 إلى 30 ياردة",
      "توصيل وسحب سريع خلال 2 إلى 4 ساعات على مدار الساعة",
      "عقود نظافة معتمدة وموثقة لتجديد الرخص التجارية",
      "تغطية شاملة لكافة أحياء ومناطق الرياض وضواحيها",
    ],
    imageUrl: "/images/container-small.png",
    statValue: "8+",
    statLabel: "سنوات خبرة في تأجير الحاويات ونقل الأنقاض",
  },
  why: {
    titlePrefix: "لماذا تختار",
      titleHighlight: "{{company_name}}؟",
    description: "نلتزم بأعلى معايير السرعة والموثوقية والسلامة البيئية، مع توفير حاويات مناسبة لجميع أنواع المشاريع الإنشائية والتجارية.",
    points: [
      "سرعة الاستجابة والتوصيل الفوري 24/7",
      "تنوع مقاسات الحاويات (6، 10، 12، 15، 20، 30 ياردة)",
      "مكابس نفايات كهربائية وهيدروليكية للمنشآت",
      "عقود سنوية ودورية معتمدة من أمانة الرياض",
      "أسعار واضحة وتنافسية بدون أي رسوم خفية",
      "تفريغ قانوني وآمن في المرادم المعتمدة",
      "فريق دعم فني وسائقون محترفون على دراية بأحياء الرياض",
      "خصومات خاصة للمقاولين والمشاريع الكبرى",
    ],
    imageUrl: "/images/container-large.png",
    badgeValue: "✓",
    badgeTitle: "شريك معتمد وموثوق",
    badgeDescription: "خدمة 24 ساعة بالرياض",
  },
  how: {
    eyebrow: "طريقة العمل",
    title: "اطلب حاويتك في 4 خطوات بسيطة",
    description: "عملية حجز سريعة وسلسة تبدأ بطلبك وتنتهي بتسليم وسحب الحاوية في موعدك المحدد.",
    steps: [
      { number: "01", title: "اختر الحاوية", subtitle: "الحجم والنوع المناسب", description: "استعرض الحاويات المتاحة (أنقاض أو نفايات) واختر المقاس المناسب لمشروعك." },
      { number: "02", title: "حدد الموقع والتفاصيل", subtitle: "بيانات التوصيل", description: "أدخل موقع مشروعك في الرياض ونوع المخلفات والفترة المطلوبة." },
      { number: "03", title: "التوصيل والتفريغ", subtitle: "وصول فوري للموقع", description: "تصلك الحاوية في الوقت المحدد عبر سائقين محترفين وشاحنات مجهزة." },
      { number: "04", title: "السحب أو الاستبدال", subtitle: "إتمام الخدمة", description: "عند امتلاء الحاوية نقوم بسحبها فوراً أو استبدالها لمواصلة العمل دون انقطاع." },
    ],
    ctaText: "اطلب حاويتك الآن",
    footnote: "نصلك في جميع أحياء الرياض وضواحيها خلال وقت قياسي.",
  },
  areas: {
    eyebrow: "نطاق التغطية",
    title: "خدمات تأجير الحاويات في",
    highlight: "جميع أحياء الرياض",
    description: "أسطولنا الميداني يغطي كافة مناطق وأحياء الرياض وضواحيها مع سرعة وصول فائقة.",
    items: [
      { slug: "شمال-الرياض", name: "شمال الرياض", description: "الملقا، النرجس، الياسمين، الصحافة، حطين، العارض، القيروان." },
      { slug: "شرق-الرياض", name: "شرق الرياض", description: "الروضة، النسيم، المونسية، الرمال، القادسية، قرطبة، اليرموك." },
      { slug: "غرب-الرياض", name: "غرب الرياض", description: "لبن، طويق، ظهرة لبن، السويدي، العريجاء، البديعة." },
      { slug: "جنوب-الرياض", name: "جنوب الرياض", description: "الشفا، بدر، العزيزية، الدار البيضاء، المصانع، نمار." },
      { slug: "وسط-الرياض", name: "وسط الرياض", description: "الملز، البطحاء، المربع، العليا، السليمانية، الديرة." },
      { slug: "الدرعية-والضواحي", name: "الدرعية والضواحي", description: "الدرعية، العمارية، صلبوخ، والمناطق المجاورة." }
    ],
    missingText: "هل موقعك خارج هذه القوائم؟",
    phonePrefix: "اتصل بنا مباشرة على",
    phoneSuffix: "لتأكيد التوصيل لموقعك فوراً.",
  },
  sections: {
    services: {
      eyebrow: "خدماتنا المتميزة",
      title: "خدمات متكاملة في",
      highlight: "إدارة الحاويات ونقل الأنقاض",
      description: "حلول متطورة لنقل مخلفات البناء والهدم، ردم وتسوية الأراضي، وتنظيف المواقع الإنشائية.",
      detailsLabel: "تفاصيل الخدمة",
    },
    packages: {
      title: "حاويات",
      highlight: "{{company_name}} المتاحة",
      description: "اختر الحجم والفئة المناسبة لاحتياجات مشروعك (أنقاض، نفايات، عقود نظافة ومكابس).",
    },
    values: {
      title: "قيمنا وركائزنا",
      description: "مبادئنا الثابتة في الالتزام بالمواعيد والجودة والامتثال لمعايير السلامة والبيئة.",
    },
    testimonials: {
      title: "آراء وتقييمات العملاء",
      description: "ثقة كبرى شركات المقاولات وأصحاب المشاريع والمنشآت في خدماتنا.",
    },
    blog: {
      eyebrow: "المدونة المعرفية",
      title: "دليل ومقالات تأجير الحاويات",
      description: "إرشادات عملية ونصائح لاختيار الحجم الأمثل وأحدث أسعار الحاويات في الرياض.",
      allArticles: "استعراض جميع المقالات",
    },
    contact: {
      title: "هل تحتاج إلى استشارة أو عرض سعر مخصص؟",
      description: "فريقنا متواجد على مدار الساعة للرد على استفساراتك وتلبية طلباتك.",
      whatsappText: "تواصل عبر واتساب (0536312121)",
      callText: "اتصال هاتفي مباشر (0536312121)",
    },
  },
};

const settings = [
  ["site_desc", "{{company_name}} — الرائدون في تأجير حاويات المخلفات ونقل الأنقاض بالرياض. حاويات بمقاسات متعددة وسرعة في الأداء ودقة في المواعيد. اتصل الآن: 0536312121"],
  ["company_name", "تأجير حاويات الرياض"],
  ["company_phone_call", "0536312121"],
  ["company_phone_whatsapp", "0536312121"],
  ["company_phones", JSON.stringify(["0536312121"])],
  ["company_footer_description", "{{company_name}}، خيارك الأمثل في عالم تأجير الحاويات ونقل الأنقاض. نقدم خدماتنا بجودة عالية وأسعار تنافسية لنكون شركاء نجاحك في مشاريعك الإنشائية."],
  ["homepage_content", JSON.stringify(homepageContent)],
  ["sections_order", JSON.stringify([
    "hero",
    "stats",
    "services",
    "packages",
    "about",
    "ceo",
    "how_it_works",
    "why_choose_us",
    "areas",
    "values",
    "testimonials",
    "partners",
    "blog",
    "service_request",
    "contact",
  ])],
  ["sections_hidden", "[]"],
] as const;

for (const [key, value] of settings) {
  const existing = db.select().from(siteSettingsTable).where(eq(siteSettingsTable.key, key)).get();
  if (existing) {
    db.update(siteSettingsTable)
      .set({ value, updatedAt: new Date().toISOString() })
      .where(eq(siteSettingsTable.key, key))
      .run();
  } else {
    db.insert(siteSettingsTable).values({ key, value }).run();
  }
}

console.log("Homepage content and section order updated.");